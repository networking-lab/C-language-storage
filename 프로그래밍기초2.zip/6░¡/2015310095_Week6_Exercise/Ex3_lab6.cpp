#include <stdio.h>

int main()
{
	int arr[10], i, end, temp, size;

	printf("Enter the size of array: ");
	scanf("%d", &size);

	for (i = 0; i<size; i++){
		printf("Enter element for array[%d]: ", i);
		scanf("%d", &arr[i]);
	}
	printf("Array before: ");
	for (i = 0; i<size; i++){
		printf("%d ", arr[i]);
	}
	for (unsigned int pass = 1; pass < size; ++pass){
		for (size_t i = 0; i < size - 1; ++i){
			if (arr[i]>arr[i + 1]){
				int hold = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = hold;
			}
		}
	}
	i = 0;
	end = size - 1;
	while (i<end){
		temp = arr[i];
		arr[i] = arr[end];
		arr[end] = temp;
		i++;
		end--;
	}
	printf("\n");
	printf("Array after: ");
	for (i = 0; i<size; i++){
		printf("%d ", arr[i]);
	}
	printf("\n");
}