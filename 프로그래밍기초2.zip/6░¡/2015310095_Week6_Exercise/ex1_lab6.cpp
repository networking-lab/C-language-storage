#include <stdio.h>

int main(){
	int size, arr[10],sum=0;
	float avrg;

	printf("input size of array (max size is 10) : ");
	scanf("%d", &size);

	for (size_t i = 0; i < size; ++i){
		printf("Input the element at array[%d] : ", i);
		scanf("%d", &arr[i]);
	}
	puts("array: ");
	for (size_t i = 0; i < size; ++i){
		printf("%d ", arr[i]);
	}

	for (unsigned int pass = 1; pass < size; ++pass){
		for (size_t i = 0; i < size - 1; ++i){
			if (arr[i]>arr[i + 1]){
				int hold = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = hold;
			}
		}
	}
	puts("\n");
	puts("sorted array: ");
	for (size_t i = 0; i < size; ++i){
		printf("%d ", arr[i]);
	}
	puts("\n");
	printf("Max of array: %d\n", arr[size - 1]);
	printf("Min of array: %d\n", arr[0]);

	for (size_t i = 0; i < size; ++i){
		sum = sum + arr[i];
	}
	avrg = float (sum) / float(size);
	printf("average: %1.1f\n", avrg);
}

