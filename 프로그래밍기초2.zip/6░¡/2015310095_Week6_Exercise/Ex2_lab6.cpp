#include <stdio.h>
void print_array(int arr[], int size);
void reverse_array(int arr[], int size);

int main(){
	int size, arr[10], i;
	printf("Enter size of array: ");
	scanf("%d", &size);
	
	for (i = 0; i < size; ++i){
		printf("Input the element at array[%d] : ", i);
		scanf("%d", &arr[i]);
	}
	printf("Before: ");
	print_array(arr, size);
	printf("\n");
	reverse_array(arr, size);
	printf("After: ");
	print_array(arr, size);
	printf("\n");
}
void print_array(int arr[], int size){
	for (int i = 0; i < size; ++i){
		printf("%d ", arr[i]);
	}
}
void reverse_array(int arr[], int size){
	int temp, i=0,end=size-1;
	while (i<end){
		temp = arr[i];
		arr[i] = arr[end];
		arr[end] = temp;
		i++;
		end--;
	}
}