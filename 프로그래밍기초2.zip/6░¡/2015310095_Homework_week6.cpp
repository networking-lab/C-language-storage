//2015310095
//MOHD HAZIQ(����ũ)
//HOMEWORK_WEEK6
#include <stdio.h>
int main()
{
	int a, b, r, i = 0, counter = 0;
	unsigned int arr[250] = { 0 }; //make 250 of zero array
	printf("Enter first integer: ");
	scanf("%d", &a);
	printf("Enter second integer: ");
	scanf("%d", &b);
	r = a%b; //first remainder
	//store remainder in array until full while remainder is more than 0
	while (r>0 && i<250){
		arr[i] = r;
		a = r * 10;
		r = a%b;
		i++;
	}

	int size = sizeof(arr[i]) + 220; //take a certain size from array(size cant be beyond original array size)
	/*
	//print array if want to see it
		for(int j=0;j<size;j++){
	printf("%u ",arr[j]);
	}*/

	int  back = arr[size - 1]; //define the end of array

	//for a finite number 0 must be present inside array, so increment it,and if 0 is found then it is a finite floating number
	for (int x = 0; x<size; x++){
		if (arr[x] == 0){
			printf("length of recurrence sequence: %u\n", counter);
			return 0;
		}
	}
	//compare the end of array with k that will be decrement until the end of array same as arr[k]
	for (int k = size - 2; k>0; k--){
		if (back == arr[k]){
			counter += 1; //if it is same after the end of array then length of recurrence is just 1
			break;
		}
		else{
			counter += 1; //add counter until the end of array is the same as arr[k]
			continue;
		}
	}
	printf("length of recurrence sequence: %u\n", counter); //will print the counter as it is the length of recurrence
}