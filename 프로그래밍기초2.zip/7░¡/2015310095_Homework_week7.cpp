#include <stdio.h>

#define ROW 3
#define COL 3

void Drawboard(); //Draw board every move
int game(); //play the game
int takemove(int playerturn); //ask player1 or player2 for move
void addmove(int player[ROW][COL], int x); //add player1 or player2 moves
int checkmovesame(int player[ROW][COL], int current[ROW][COL], int x, int playerturn); //if same ask for move until move is different 
int checkwin(int A[ROW][COL], int player); //check for win

int Board[ROW][COL] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

int main(){
	game(); /*I want to ask for user if want to play again or not but i fail to do 
			so, may you edit my code if you have time*/
}
void Drawboard(){
	int i, j;
	printf("_______\n");
	for (i = 0; i < 3; i++){
		printf("|");
		for (j = 0; j < 3; j++){
			printf("%d|", Board[i][j]);
		}
		printf("\n-------\n");
	}
}
int takemove(int playerturn){
	int x,y;
	printf("Player %d, please enter your move: ",playerturn);
	scanf("%d", &x);
	y = x;
	return y;
}
void addmove(int player[ROW][COL],int x){
	if (x == 1){
		player[0][0] = x;
	}
	else if (x == 2){
		player[0][1] = x;
	}
	else if (x == 3){
		player[0][2] = x;
	}
	else if (x == 4){
		player[1][0] = x;
	}
	else if (x == 5){
		player[1][1] = x;
	}
	else if (x == 6){
		player[1][2] = x;
	}
	else if (x == 7){
		player[2][0] = x;
	}
	else if (x == 8){
		player[2][1] = x;
	}
	else if (x==9){
		player[2][2] = x;
	}
}
int checkmovesame(int player[ROW][COL], int current[ROW][COL], int x, int playerturn){
	if (x > 9 && x < 1){
		printf("Your input is out of range; range is 1~x~9...\n");
		return false;
	}
	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			if (player[i][j] == x){
				printf("Your input is been taken, try again... \n");
				return false;
			}
		}
	}
	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			if (current[i][j] == x){
				printf("Your input is been taken, try again... \n");
				return false;
			}
		}
	}
}
int checkwin(int A[ROW][COL],int player){
	if (A[0][0] + A[0][1] + A[0][2] == 6){
		printf("Player %d win!",player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[1][0] + A[1][1] + A[1][2] == 15){
		printf("Player %d win!\n",player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[2][0] + A[2][1] + A[2][2] == 24){
		printf("Player %d win!\n", player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[0][0] + A[1][0] + A[2][0] == 12){
		printf("Player %d win!\n", player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[0][1] + A[1][1] + A[2][1] == 15){
		printf("Player %d win!\n", player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[0][2] + A[1][2] + A[2][2] == 18){
		printf("Player %d win!\n", player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[0][0] + A[1][1] + A[2][2] == 15){
		printf("Player %d win!\n", player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else if (A[0][2] + A[1][1] + A[2][0] == 15){
		printf("Player %d win!\n", player);
		printf("-------------GAME OVER-------------\n");
		return true;
	}
	else{
		return false;
	}
}
int game(){
	int player1[ROW][COL] = { 0 }, player2[ROW][COL] = { 0 }, temp1, temp2;
	printf("-------TIC TAC TOE by ����ũ-------\n");
	Drawboard(); //draw the board for player to see
	//game start
	//move no.1 INITIAL MOVES (player1)
	temp1 = takemove(1); //player 1 make a move
	while (temp1 < 1 || temp1>9){
		printf("Your input is out of range; range is 1~x~9...\n");
		temp1 = takemove(1);
	}
	addmove(player1, temp1); //add move to player 1 array
	//move no.2 (player2)
	temp2 = takemove(2); //player 2 move
	while (checkmovesame(player1,player2, temp2, 2) == false){ //add move to player 2 array if not same with player 1
		temp2 = takemove(2);
	}
	addmove(player2, temp2); //add move to player 2 array
	//move no.3 (player1)
	temp1 = takemove(1); //player 2 move
	while (checkmovesame(player2,player1, temp1, 1) == false){ //add move to player 2 array if not same with player 1
		temp1 = takemove(1);
	}
	addmove(player1, temp1); //add move to player 2 array
	//move no.4 (player2)
	temp2 = takemove(2); //player 2 move
	while (checkmovesame(player1,player2, temp2, 2) == false){ //add move to player 2 array if not same with player 1
		temp2 = takemove(2);
	}
	addmove(player2, temp2); //add move to player 2 array
	//move no.5 (player1)
	temp1 = takemove(1); //player 2 move
	while (checkmovesame(player2,player1, temp1, 1) == false){ //add move to player 2 array if not same with player 1
		temp1 = takemove(1);
	}
	addmove(player1, temp1); //add move to player 2 array
	if (checkwin(player1, 1) == true){ //if player 1 win print WIN! and end program, if not skip
		return 0;
	}
	//move no.6 (player2)
	temp2 = takemove(2); //player 2 move
	while (checkmovesame(player1,player2, temp2, 2) == false){ //add move to player 2 array if not same with player 1
		temp2 = takemove(2);
	}
	addmove(player2, temp2); //add move to player 2 array
	if (checkwin(player2, 2) == true){ //if player 2 win print WIN! and end program, if not skip
		return 0;
	}
	//move no.7 (player1)
	temp1 = takemove(1); //player 2 move
	while (checkmovesame(player2,player1, temp1, 1) == false){ //add move to player 2 array if not same with player 1
		temp1 = takemove(1);
	}
	addmove(player1, temp1); //add move to player 2 array
	if (checkwin(player1, 1) == true){ //if player 1 win print WIN! and end program, if not skip
		return 0;
	}
	//move no.8 (player2)
	temp2 = takemove(2); //player 2 move
	while (checkmovesame(player1,player2, temp2, 2) == false){ //add move to player 2 array if not same with player 1
		temp2 = takemove(2);
	}
	addmove(player2, temp2); //add move to player 2 array
	if (checkwin(player2, 2) == true){ //if player 2 win print WIN! and end program, if not skip
		return 0;
	}
	//move no.9 MAX MOVES (player1)
	temp1 = takemove(1); //player 2 move
	while (checkmovesame(player2, player1,temp1, 1) == false){ //add move to player 2 array if not same with player 1
		temp1 = takemove(1);
	}
	addmove(player1, temp1); //add move to player 2 array
	if (checkwin(player1, 1) == true){ //if player 1 win print WIN! and end program, if not skip
		return 0;
	}
	else{
		printf("MATCH DRAW!\n");
		printf("-------------GAME OVER-------------\n");
		return 0;
	}
}