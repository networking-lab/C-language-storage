#include<stdio.h>

int main()
{
	int i, j, k = 1, p;
	int a[30] = { 3, 5, 2, 6, 4, 7, 3, 5, 1, 6, 3, 7, 8, 4, 9, 1, 7, 2, 4, 7, 4, 7, 4, 5, 8, 4, 2, 4, 6, 4 }; //main array
	int b[30] = {}; //new array
	int n = 30, cnt = 1, big;
	for (i = 1; i < n; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (a[i] == a[j])
				cnt++;
		}
		b[k] = cnt; //add count to b[k]
		k++; //iterate k
		cnt = 1; 
	}

	big = b[1]; //intialize big by b[1]
	p = 1; //initialize p by 1
	for (i = 2; i < n; i++)
	{
		if (big<b[i])
		{
			big = b[i];
			p = i;
		}
	}
	printf("The mode of this array is %d\n", a[p]);
}