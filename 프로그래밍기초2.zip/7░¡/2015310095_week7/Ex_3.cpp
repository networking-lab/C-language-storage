#include <stdio.h>

int main()
{
	int arr1[2][2] = { 0 }, arr2[2][2] = { 0 }, sumarr[2][2] = { 0 };

	printf("Enter first matrix: ");
	scanf("%d %d %d %d", &arr1[0][0], &arr1[0][1], &arr1[1][0], &arr1[1][1]);
	printf("Enter second matrix: ");
	scanf("%d %d %d %d", &arr2[0][0], &arr2[0][1], &arr2[1][0], &arr2[1][1]);
	printf("Matrix first: \n");
	for (int i = 0; i<2; i++){
		for (int j = 0; j<2; j++){
			printf("%d ", arr1[i][j]);
		}
		printf("\n");
	}
	printf("Matrix second: \n");
	for (int i = 0; i<2; i++){
		for (int j = 0; j<2; j++){
			printf("%d ", arr2[i][j]);
		}
		printf("\n");
	}
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			int sum = 0;
			for (int k = 0; k < 2; k++) {
				sum = sum + arr1[i][k] * arr2[k][j];
			}
			sumarr[i][j] = sum;
		}
	}
	printf("Multiplication of two matrices: \n");
	for (int i = 0; i<2; i++){
		for (int j = 0; j<2; j++){
			printf("%d ", sumarr[i][j]);
		}
		printf("\n");
	}
}


