#include <stdio.h>
void linearsearch(int arr[], int num, int count);

int main()
{
	int arr[10] = { 3, 7, 2, 5, 1, 4, 9, 6, 8, 3 }, num, count = 0;
	printf("Which number: ");
	scanf("%d", &num);
	linearsearch(arr, num, count);
}
void linearsearch(int arr[], int num, int count){
	int last = arr[count - 1];
	if (arr[count] == num){
		printf("Element %d is present at index %d\n", num, count);
	}
	else{
		if (arr[count] == last){
			printf("Element %d is not present\n", num);
		}
		else{
			return(linearsearch(arr, num, count + 1));
		}
	}
}

