#include <stdio.h>

int main(void){
	int a = 2, c = 1;
	while (c < 10){
		printf("%d x %d = %d\n", a, c, a*c);
		c++;
	}
}