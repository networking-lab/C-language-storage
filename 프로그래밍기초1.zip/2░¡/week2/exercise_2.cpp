#include <stdio.h>

int main(void){
	int a = 50, b = 60, c = 70;
	float N = (a + b + c) / 3;
	printf("%d %d %d\n", a, b, c);
	if (N > 60){
		printf("Average : %f\n", N);
		puts("Pass");
	}
	if (N == 60){
		printf("Average : %f\n", N);
		puts("Barely pass");
	}
	if (N > 60){
		printf("Average : %f\n", N);
		puts("Fail");
	}
}