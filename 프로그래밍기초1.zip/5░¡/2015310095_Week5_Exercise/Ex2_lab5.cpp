#include <stdio.h>
int sumnum(int a);

int main(){
	int k;
	printf("Enter a positive integer: ");
	scanf("%d", &k);
	printf("Sum of digits: %d\n", sumnum(k));
}
int sumnum(int a){
	if (a == 0){
		return 0;
	}
	else{
		int s = 0;
		s = a % 10;
		int sumn = s;
		return(sumn + sumnum(a / 10)); //recursion part
	}
}