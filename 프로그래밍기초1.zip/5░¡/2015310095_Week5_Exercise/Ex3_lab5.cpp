#include <stdio.h>
int GCD(int x, int y);

int main(){
	int a, b;
	printf("Enter a first positive integer: ");
	scanf_s("%d", &a);
	printf("Enter a second positive integer: ");
	scanf_s("%d", &b);
	printf("GCD of %d, %d is %d\n", a, b, GCD(a, b));
}

int GCD(int x, int y){
	if (y == 0){
		return(x);
	}
	else{
		return(GCD(y, x%y)); //recursion part
	}
}