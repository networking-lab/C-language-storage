#include <stdio.h>
int x = 1234;
float y = 1.234567;
void function_1(){
	printf("From function_1: x=%d, y=%f\n", x, y);
}
int main(){
	int i = 32;
	int x = 4321;
	function_1(); //call function
	printf("Within the main block: x=%d, y=%f\n", x, y);
	printf("Within the outer block: i=%d\n", i);
	{
		double y = 7.654320;
		function_1(); //call function
		printf("Within the nested block: x=%d, y=%f\n", x, y);
		int i = 5, j;
		printf("Within the inner block:\n");
		for (j= 10; j > 0; j--){
			printf("i=%d, j=%d\n", i, j);
		}
	}
	printf("Within the outer block: i=%d\n", i);
	return 0;
}