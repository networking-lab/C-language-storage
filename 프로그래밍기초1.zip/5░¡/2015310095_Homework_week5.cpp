#include <stdio.h>
void HANOI(int disk, char frompeg, char topeg, char auxpeg);
int move(int disk, char frompeg, char topeg); //print move, and add i by 1 every move
unsigned int i = 0; //global i

int main(){
	int disk;
	printf("Enter number of disks: ");
	scanf("%d", &disk);
	printf("The sequence of moves involved in the Tower of Hanoi are: \n");
	HANOI(disk, 'A', 'C', 'B');
	printf("Total: %d moves\n", i);
}
void HANOI(int disk, char frompeg, char topeg, char auxpeg){
	if (disk == 1){
		i += move(disk,frompeg,topeg);
	}
	else{
		HANOI(disk - 1, frompeg, auxpeg, topeg);
		i += move(disk,frompeg,topeg);
		HANOI(disk - 1, auxpeg, topeg, frompeg);
	}
}
int move(int disk, char frompeg, char topeg){
	printf("Move disk %d from peg %c to peg %c\n", disk, frompeg, topeg);
	return 1;
}