#include <stdio.h>
int gcd(int x, int y); //GCD(x,y) function definition

int main(){
	int a, b;
	printf("Enter two integer to find GCD:\n");
	printf("a -> ");
	scanf("%d", &a);
	printf("b -> ");
	scanf("%d", &b);
	printf("GCD(%d,%d) is %d\n", a,b,gcd(a, b));

}
int gcd(int x, int y){
	int r = x % y; //Find the first remainder
	//Just using euclidean algorithm's logic switch remainder with our y loop the calculation until remainder is 0
	while (r != 0){
		x = y;
		y = r;
		r = x % y;
		if (r == 0){
			return y; //then return(y) as it is our GCD
		}
	}
}