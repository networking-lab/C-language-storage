#include <stdio.h>
#include <stdlib.h>
int myrand(int a, int b);

int main(){
	int a, b, list[5];
	printf("Enter your range from a~b\n");
	printf("From a: ");
	scanf("%d", &a);
	printf("to b: ");
	scanf("%d", &b);
	for (int i = 0; i < 5; i++){
		list[i] = myrand(a, b);
		printf("%d ", list[i]);
	}
	printf("\n");
}
int myrand(int a, int b){
	int r = rand() % (b-a+1)+a;
	return r;
}