#include <stdio.h>
#define A 5/9
int F2C(int F);

int main(){
	int F;
	printf("Convert any tempreture to celcius from farenheit -> ");
	scanf("%d", &F);
	printf("%d^F in celcius is %d^C\n", F, F2C(F));

}
int F2C(int F){
	int c = (F - 32)*A;
	return c;
}