#include <stdio.h>
#include <math.h>
double quadratic(int a, int b, int c);

int main(){
	int a, b, c;
	printf("Enter 3 coeffecient a,b and c");
	printf("\na -> ");
	scanf("%d", &a);
	printf("\nb -> ");
	scanf("%d", &b);
	printf("\nc -> ");
	scanf("%d", &c);
	if (a == 0){
		while (a == 0){
			printf("coefficient a cant be 0");
			scanf("%d", &a);
		}
	}
	printf("answer is %lf\n", quadratic(a, b, c));
}
double quadratic(int a, int b, int c){
	float y1 = (b*b) - (4 * a*c);
	double y2 = sqrt(y1);
	double x1 = (-b + y2) / (2 * a);
	return x1;
}