#include <stdio.h>

int main(){
	int n; //define variable n
	int result,i; //same for result and i
	printf("Enter any number to check it's prime factors: ");
	scanf("%d", &n); //take input from user
	printf("|||||\n|||||\n");
	printf("All prime factors of %d are: \n", n);
	//for i to n , devide n % i and if the result 0 it is one the factor 
	for (i = 2; i < n; i++){
		result = n % i;
		if (result == 0){
			printf("%d\n", i);
		}
	}
}