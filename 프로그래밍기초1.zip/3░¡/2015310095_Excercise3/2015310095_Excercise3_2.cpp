#include <stdio.h>

int main(){
	int user_row; //define variable
	printf("enter number of row you want: ");
	scanf("%d", &user_row); //take input for number of row
	int row, Colspace, Colstar;
	//uppper part of diamond
	for (row = 1; row <= user_row; row++){
		for (Colspace = user_row - row; Colspace >= 1; Colspace--){
			printf(" ");
		}
		for (Colstar = 1; Colstar <= (row * 2) - 1; Colstar++){
			printf("*");
		}
		printf("\n");
	}
	//lower part of diamond
	for (row = user_row - 1; row >= 1; row--){
		for (Colspace = 1; Colspace <= user_row-row; Colspace++){
			printf(" ");
		}
		for (Colstar = 1; Colstar <= (row * 2) - 1; Colstar++){
			printf("*");
		}
		printf("\n");
	}
}