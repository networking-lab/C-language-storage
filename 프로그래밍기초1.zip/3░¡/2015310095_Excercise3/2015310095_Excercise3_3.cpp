#include <stdio.h>

int main(){
	int usernum;
	int index;
	int sumofnumber=0;
	printf("Enter a possible perfect number: ");
	scanf("%d", &usernum); //take input number
	//calculate the sum of factors of user's number
	for (index = 1; index < usernum; index++){
		if (usernum % index == 0){
			sumofnumber += index;
		}
	}
	//if user number and sum of factors is the same than it is a perfect number
	if (usernum == sumofnumber){
		printf("%d is a perfect number!!\n", usernum);
	}
	//else it is not
	else
		printf("%d is not a perfect number!!\n", usernum);
}