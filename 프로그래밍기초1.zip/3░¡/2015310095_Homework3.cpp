//2015310095_Homework3
#include <stdio.h>

int main(){
	int usernumber, reversenumber=0, answer; //define three main variable

	printf("Enter any possible Palindrome numbers: ");
	scanf("%d", &usernumber); //take input from user

	/*
	Start with reversenumber intialized as 0..
	Then, we assign variable usernumber to answer...
	A simple logic equation of n = (n*10)+m%10 is use to store the end of the numbers...
	Then we divide the answer with 10 to eliminate the end of the numbers...
	"For loop" will continue until answer reach 0,then it will move to the "if else" statement...
	*/
	for (answer = usernumber; answer != 0;){
		reversenumber = (reversenumber * 10) + answer % 10;
		answer = answer / 10;
	}
	//if user numbers same as the reverse numbers, print "it is a palindrome number"
	//else it is not
	if (usernumber == reversenumber){
		printf("reverse of %d is %d\n", usernumber, reversenumber);
		printf("%d is a Palindrome numbers\n", usernumber);
	}
	else{
		printf("reverse of %d is %d\n", usernumber, reversenumber);
		printf("%d is not a Palindrome numbers\n", usernumber);

	}
}